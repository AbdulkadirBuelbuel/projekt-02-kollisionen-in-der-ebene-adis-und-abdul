package app;
public class Main {
    public static void main(String[] args) {
        Animation animation = null;
        animation = new app.Eingabefenster();
        animation.start();
    }
}
