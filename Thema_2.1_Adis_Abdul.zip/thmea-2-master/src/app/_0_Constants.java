package app;
public class _0_Constants {
    public static int FPS = 60;
    public static int TPF = 1000/FPS;
    public static double TIMESCALE = 1.0;

}
